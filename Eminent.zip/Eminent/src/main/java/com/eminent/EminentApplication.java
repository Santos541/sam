package com.eminent;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EminentApplication {

	public static void main(String[] args) {
		SpringApplication.run(EminentApplication.class, args);
	}

}
