package com.eminent.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class Controller {

    @RequestMapping("/login")
    String helloWorld() {
        return "Hello World!";
    }

}